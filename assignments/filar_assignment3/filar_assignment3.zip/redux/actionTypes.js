//actionTypes.js
//actiontypes are unique strings that represent 
// operations allowed on the states


export const BOOK_ROOM = "BOOK_ROOM";
export const DELETE_BOOKING = "DELETE_BOOKING";