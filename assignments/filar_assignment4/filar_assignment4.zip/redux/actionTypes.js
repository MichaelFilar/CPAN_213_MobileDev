//actionTypes.js
//actiontypes are unique strings that represent 
// operations allowed on the states


export const ADD_PARKING = 'ADD_PARKING';
export const FETCH_PARKING = 'FETCH_PARKING';
export const EDIT_PARKING = 'EDIT_PARKING';
export const DELETE_PARKING = 'DELETE_PARKING';