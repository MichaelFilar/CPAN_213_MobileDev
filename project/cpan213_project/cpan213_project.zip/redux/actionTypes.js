//actionTypes.js
//actiontypes are unique strings that represent 
// operations allowed on the states


export const GET_JOKE = 'GET_JOKE';
export const SAVE_JOKE = 'SAVE_JOKE';
export const LOG_IN = 'LOG_IN';