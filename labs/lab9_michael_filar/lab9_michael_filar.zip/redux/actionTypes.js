//actionTypes.js
//actiontypes are unique strings that represent 
// operations allowed on the states


export const ADD_BOOK = 'ADD_BOOK';
export const FETCH_BOOKS = 'FETCH_BOOKS';